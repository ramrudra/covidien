

  <div class="homeBanner"><img src="<?php echo "/sites/default/files/".$node->field_banner_background['und'][0]['filename'];?>"  alt="" />
  <div class="leftslider">
  <h1 class="title"><?php print $node->title; ?></h1>
  <p><?php print $node->body['und'][0]['value']; ?></p>
  </div>
  </div>
