<?php if (isset($_GET['simplycontent'])) {
   print render($page['content']);
   exit;
} ?>
<?php global $base_url, $theme_path; ?>
<div id="layout">
<div id="head">
    <div id="logo"><a href="<?php echo $base_url;?>"><img src="<?php print $logo ?>" alt="" /></a></div>
</div>
  <div id="header">

    <div class="top-bar">
     <ul>
      <li class="lang"><a href="#">Language</a>
       <ul>
        <li><a href="#">English</a></li>
        <li><a href="#">French</a></li>
       </ul>
      
      </li>
      
     </ul>
         </div>

     <div class="head-search">
        <input type="text" value="Covidien.com" />
        <input type="button" value="" class="btn" />
      </div>
<div id="mainNav">
   <?php if ($primary_nav): print $primary_nav; endif; ?>
<div class="clr"></div>
</div>    
  </div>
  <!-- Content and banner area -->
  
<?php 
      if((!isset($node)) && (arg(1)!='location')) { ?>
	  
	  <div id="home-content">
   <!--div class="homeBanner"><img src="<?php echo $base_url."/".$theme_path; ?>/images/home-banner.jpg" alt="" />
  <div class="leftslider">
  <h1>Are you innovative?</h1>
  <p>Lorem ipsum dolor sit amet, cotetur ad
iscing elit. Curabur cursus elit et mauris is volutpat vestibum. Nulla in laoreeaq</p>
  </div>
  <div class="slider">
  <div class="arrow"><a href="#"><img src="<?php echo $base_url."/".$theme_path; ?>/images/slider-arrow.png"></a></div>
  <div class="left">
  <div><img src="<?php echo $base_url."/".$theme_path; ?>/images/banner-slider-img.png"></div>
  <p>Covidien Stories: <span>"Why my disability 
is no barrier to my...</span></p>
</div>
  </div>
  
  <div class="bannerNav">
  <ul>
   <li class="caring"><a href="#">Are you caring?</a></li>
    <li class="global"><a href="#">Are you global?</a></li>
     <li class="innovative-active"><a href="#">Are you innovative?</a></li>
      <li class="covidien"><a href="#">Are you Covidien?</a></li>
  
  </ul>
  
  </div>
  </div-->
  <div id="innerpage_leftcol">
	  	  <?php if ($tabs): ?><div id="tabs-wrapper" class="clearfix"><?php endif; ?>	 
	  <?php if ($title): ?>
		<h1<?php print $tabs ? ' class="with-tabs"' : '' ?>><?php print $title ?></h1>
	  <?php endif; ?>	 
	  <?php if ($tabs): ?><?php print render($tabs); ?></div><?php endif; ?>
	  <?php print render($tabs2); ?>
	  <?php print $messages; ?>

	<?php print render($page['content']); ?>
  </div>
<div id="rightCol">
	 
  </div>
  <div class="clr"></div>
 </div>
	  
 <?php 	} else {  
	   if(isset($node) && ($node->type == "career_page" or $node->type == "culture_page" or $node->type == "about_us_page")) {  ?>
	   
 <!-- Content and banner for career pages -->	
    
<div id="careers" class="careers">
  <!-- Career Page-->
  <!--?php
if ($node->nid == "9" <!--or $node->nid == "13" or $node->nid == "14" or $node->nid == "15" or $node->nid == "16" or $node->nid == "24"){
?-->

  <?php
if ($node->nid == "9"){
?>
  <?php
          $block = module_invoke('nodeblock', 'block_view', '113');
          print render($block['content']); 
?>
<?php
          $block = module_invoke('views', 'block_view', 'covidien_stories-block_2');
          print render($block['content']); 
?>  <?php
}
?>
<!-- End career Page -->
<!-- career Page -->
<!--?php
if ($node->nid == "10" or $node->nid == "21" or $node->nid == "22" or $node->nid == "43" or $node->nid == "44" or $node->nid == "45" or $node->nid == "92"){
?-->
<?php
if ($node->nid == "92"){
?>
  <?php
          $block = module_invoke('nodeblock', 'block_view', '114');
          print render($block['content']); 
?>
<?php
          $block = module_invoke('views', 'block_view', 'covidien_stories-block_3');
          print render($block['content']); 
?>  <?php
}
?>
<!-- End career Page -->
<!-- About Page -->
<!--?php
if ($node->nid == "18" or $node->nid == "19" or $node->nid == "20" or $node->nid == "46" or $node->nid == "47" or $node->nid == "93" or $node->nid == "94"){
?-->
<?php
if ($node->nid == "93"){
?>


  <?php
          $block = module_invoke('nodeblock', 'block_view', '115');
          print render($block['content']); 
?> 
<?php
          $block = module_invoke('views', 'block_view', 'covidien_stories-block_4');
          print render($block['content']); 
?> <?php
}
?>

<!-- About Page -->
  <div id="leftCol">
  <?php if($node->type == "career_page")
      echo "<h2>Careers</h2>";
	   elseif($node->type == "culture_page")
        echo "<h2>Covidien Culture</h2>";
		elseif($node->type == "about_us_page")
		{
        echo "<h2>About Us</h2>"; 
	   print render($page['aboutus_leftside']);  
		}
		?>
		
	 <?php if ($page['career_leftside']): ?>        
          <?php print render($page['career_leftside']); ?>      
     <?php endif; ?>
  
    
  <!--<ul>
   <li class="active"><a href="#">Job Functions</a>
   <ul>
   <li class="active"><a href="#">Communication</a></li>
   <li><a href="#">Customer Operations</a></li>
   <li><a href="#">Engineering</a></li>
   <li><a href="#">Environmental Health & Safety</a></li>
   <li><a href="#">Finance</a></li>
   <li><a href="#">Human Resources</a></li>
   <li><a href="#">Information Services</a></li>
   <li><a href="#">Legal</a></li>
   <li><a href="#">Manufacturing</a></li>
   <li><a href="#">Marketing</a></li>
   <li><a href="#">Medical & Clinical Affairs</a></li>
   <li><a href="#">Operational Excellence</a></li>
   <li><a href="#">Project Management</a></li>
   <li><a href="#">Procurement/Logistics</a></li>
   <li><a href="#">Quality</a></li>
   <li><a href="#">Regulatory Affairs</a></li>
   <li><a href="#">Research & Development</a></li>
   <li><a href="#">Sales</a></li>
   <li><a href="#">Strategy & Business</a></li>
      <li><a href="#">Development & Licencing</a></li>

   </ul>
  </li>
  </ul>-->
  
  
  </div>
  <div id="midCol">
      <?php if ($tabs): ?><div id="tabs-wrapper" class="clearfix"><?php endif; ?>
	  <?php if ($tabs): ?><?php print render($tabs); ?></div><?php endif; ?>
	  <?php print render($tabs2); ?>
	  <?php print $messages; ?>	 
	  <?php if ($title): ?> <h2><?php print $title; ?></h2><?php endif; ?>
  <?php print render($page['content']); ?>
   
  </div>
  <div id="rightCol">
    

<?php


if ($node->type == "career_page"){
?>
  <?php
          $block = module_invoke('views', 'block_view', 'widget_blocks-block_1');
          print render($block['content']); 
?>
<?php
}
?>


<?php


if ($node->type == "culture_page"){
?>
  <?php
          $block = module_invoke('views', 'block_view', 'widget_blocks-block_3');
          print render($block['content']); 
?>
<?php
}
?>

<?php


if ($node->type == "about_us_page"){
?>
  <?php
          $block = module_invoke('views', 'block_view', 'widget_blocks-block_4');
          print render($block['content']); 
?>
<?php
}
?>
<div class="tagged-stories">
<?php
          $block = module_invoke('views', 'block_view', 'covidien_stories-block_9');
          print render($block['content']); 
?></div>
<!--div class="box">
  <h2>Careers@Covidien</h2>
  <div>
      <select name="covidiencareer" id="covidiencareer">
    <option value=''>Select a job function</option>
    <?php $jobs = getAllJobFunction();
      foreach($jobs as $job) {
    ?>
      <option value='<?php print $job; ?>'><?php print $job; ?></option>
    <? } ?>
    </select>
  <p>There are 943 openings globally.</p>
  </div>  
  <div class="clr"></div>
  <div class="btn"><a href="<?php print $base_url;?>/covidien/location/search">Search</a></div>
    <div class="graybtn"><a href="<?php print $base_url;?>/covidien/location/search">Advanced Search</a></div>
  <div class="clr"></div>
  </div-->
   </div>
  <div class="clr"></div>
 
  </div>
	   
	<?php } elseif( (isset($node) && ($node->type == "job")) || (arg(2)=='summary') || (arg(2)=='search')) { 
	
	  ?>
	  <div id="job">
<?php if((arg(1)=='location') && (arg(2)=='search')) { ?>
<h1 style="color:#003878; margin-left:20px;">Search Result</h1>
	  <div class="job_search" style="width:960px; margin:10px 20px; overflow:auto">
	<form id="search_frm" name="search_frm" action="<?php print $base_url;?>/covidien/location/search" method="post">
	<input type="hidden" id="page" name="page" />
	<div style="float:left;width:650px">
	<select name="jobname" id="jobname" onchange="">
		<option value="">Job Functions</option>
	<?php 	$jobs = getAllJobFunction();
		$post = '';
		if(isset($_POST['jobname'])) { $post = $_POST['jobname']; }
		foreach($jobs as $job) { $sel = ''; if($post == $job) { $sel = 'selected = "selected"'; } ?>
		<option value="<?php print $job;?>" <?php print $sel;?>><?php print $job;?></option>
	<?php } ?>
	</select>
	<select name="jobcountry" id="jobcountry" onchange="cityvalues()">
		<option value="">Country</option>
	<?php 	$jobs = getAllJobCountry();
		$post = '';
		if(isset($_POST['jobcountry'])) { $post = $_POST['jobcountry']; }
		foreach($jobs as $job) {  $sel = ''; if($post == $job) { $sel = 'selected = "selected"'; } ?>
		<option value="<?php print $job;?>" <?php print $sel;?>><?php print $job;?></option>
	<?php } ?>
	</select>
	<select name="jobcity" id="jobcity" style='width:130px;'>
		<option value="">City</option>
		<?php
		$jobs = getAllJobCity($post);
		if(isset($_POST['jobcountry'])) { $post = $_POST['jobcity']; }
		foreach($jobs as $job) {  $sel = ''; if($post == $job) { $sel = 'selected = "selected"'; } ?>
		<option value="<?php print $job;?>" <?php print $sel;?>><?php print $job;?></option>
	<?php } ?>
	</select>
	</div>
	<div class="buttons"><a href="#" class="link" onclick="showdiv()">Advanced Search</a></div>
	<div class="buttons"><a href="#" class="link" onclick="submitform()">Search</a></div>
<div style="display:none; border-top:1px solid #ddd; margin-top:5px; clear:both; padding-top:5px;" id="advanced">
	<div style="width:650px; float:left">
		<select name="jobfamily" id="jobfamily" onchange="" style="width:420px; height:100px; float:left" multiple="multiple">
		<?php 	$jobs = getAllJobFamily();
			$post = '';
			if(isset($_POST['jobfamily'])) { $post = $_POST['jobfamily']; }
			foreach($jobs as $job) {  $sel = ''; if($post == $job) { $sel = 'selected = "selected"'; }?>
			<option value="<?php print $job;?>" <?php print $sel;?>><?php print $job;?></option>
		<?php } ?>
		</select>
		<div style="float:left; width:220px;">Multiple job families may be selected. Scroll the list for more options;</div>
	</div>
	<div style="float:left; width:300px"><input type="text" id="jobloc" name="keyword" style="width:200px" value="<?php if(isset($_POST['keyword'])) { print $_POST['keyword'];} else { echo "Keyword"; }?>" /><br /><input type="text" id="jobloc" name="jobid" style="width:200px" value="<?php if(isset($_POST['jobid'])) { print $_POST['jobid'];} else { echo "Job Opening ID"; }?>" /><br />There are currently (300) vacancies at covidien with this criteria.</div>
</div>
	<input type="hidden" name="title" id="title" value="" />
</form>

</div>
<?php } ?>
<div id="left-col">
 <?php if ($tabs): ?><div id="tabs-wrapper" class="clearfix"><?php endif; ?>	 
	  	 
	  <?php if ($tabs): ?><?php print render($tabs); ?></div><?php endif; ?>
	  <?php print render($tabs2); ?>
	  <?php print $messages; ?>
	    
	<?php print render($page['content']); ?>
</div>

  <div id="rightCol">
<h2>Alert me to careers</h2>
<ul>
<li><select name="jobname_alert" id="jobname_alert" onchange="">
		<option value="">Job Functions</option>
	<?php 	$jobs = getAllJobFunction();
		foreach($jobs as $job) { ?>
		<option value="<?php print $job;?>"><?php print $job;?></option>
	<?php } ?>
	</select>
</li>
<li><select name="jobcountry_alert" id="jobcountry_alert" onchange="">
		<option value="">Country</option>
	<?php 	$jobs = getAllJobCountry();
		foreach($jobs as $job) {  ?>
		<option value="<?php print $job;?>"><?php print $job;?></option>
	<?php } ?>
	</select></li>
<li><select name="jobcity_alert" id="jobcity_alert" style='width:130px;'>
		<option value="">City</option>
		<?php
		$post = '';
		$jobs = getAllJobCity($post);
		foreach($jobs as $job) {  ?>
		<option value="<?php print $job;?>"><?php print $job;?></option>
	<?php } ?>
	</select>
</li>
<li><input type="text" value="Enter your Email address" /></li>
<li><span>Agree to <a href="#">Terms and Conditions</a></span><input type="checkbox" /></li>
<li><input type="submit" value="Submit" id="alert" name="alert" /></li>

</ul>
  </div>
  <div class="clr"></div>
 
  </div>
	  
	  
	  
	 <?php } else { ?> 
  
  
  <div id="home-content">
<?php if((isset($node)) && ($node->type != "location") && (arg(1)!='location')) { ?>	



  


  <!--div class="homeBanner"><img src="<?php echo $base_url."/".$theme_path; ?>/images/home-banner.jpg" alt="" />
  <div class="leftslider">
  <h1>Are you innovative?</h1>
  <p>Lorem ipsum dolor sit amet, cotetur ad
iscing elit. Curabur cursus elit et mauris is volutpat vestibum. Nulla in laoreeaq</p>
  </div>
  <div class="slider">
  <div class="arrow"><a href="#"><img src="<?php echo $base_url."/".$theme_path; ?>/images/slider-arrow.png"></a></div>
  <div class="left">
  <div><img src="<?php echo $base_url."/".$theme_path; ?>/images/banner-slider-img.png"></div>
  <p>Covidien Stories: <span>"Why my disability 
is no barrier to my...</span></p>
</div>
  </div>
  
  <div class="bannerNav">
  <ul>
   <li class="caring"><a href="#">Are you caring?</a></li>
    <li class="global"><a href="#">Are you global?</a></li>
     <li class="innovative-active"><a href="#">Are you innovative?</a></li>
      <li class="covidien"><a href="#">Are you Covidien?</a></li>
  
  </ul>
  
  </div>
  </div-->
<?php } ?>   
  <div id="innerpage_leftcol">
	 
	  <?php if ($tabs): ?><div id="tabs-wrapper" class="clearfix"><?php endif; ?>
	 
	  <?php if ($title): ?>
		<h1<?php print $tabs ? ' class="with-tabs"' : '' ?>><?php print $title ?></h1>
	  <?php endif; ?>
	 
	  <?php if ($tabs): ?><?php print render($tabs); ?></div><?php endif; ?>
	  <?php print render($tabs2); ?>
	  <?php print $messages; ?>
	 	  
	<?php print render($page['content']); ?>
  </div>
<?php  if((isset($node)) && ($node->type!='location') && (arg(1)!='location')) { ?>
<div id="rightCol">
	  <h1>Careers@Covidien</h1>
	  <div>
		<select name="covidiencareer" id="covidiencareer">
		<option value=''>Select a job function</option>
		<?php $jobs = getAllJobFunction();
			foreach($jobs as $job) {
		?>
			<option value='<?php print $job; ?>'><?php print $job; ?></option>
		<? } ?>
	  </select>
	  </div>
	  <h3>Latest Covidien Careers</h3>
  <ul>
  <?php $arr = getLatestJobs();?>
  <?php for($i=0; $i<5;$i++) { ?>
  <li><a href="<?php print $base_url;?>/covidien/location/summary/<?php print $arr['id'][$i];?>"><?php print $arr['name'][$i];?>,<br />
Location: <?php print $arr['location'][$i];?></a></li>
	<?php } ?>
  </ul>
  <div class="clr"></div>
  <div class="btn"><a href="<?php print $base_url;?>/covidien/location/search">More Results</a></div>
	<div class="graybtn"><a href="<?php print $base_url;?>/covidien/location/search">Advanced Search</a></div>
  </div>
<?php } else if((isset($node) && $node->type=='location') || (arg(1)=='location' && (arg(2)=='details'))) { ?>
<div id="rightCol">

  <?php
          $block = module_invoke('views', 'block_view', 'covidien_stories-block_1');
          print render($block['content']); 
?>

<?php
          $block = module_invoke('views', 'block_view', 'widget_blocks-block_2');
          print render($block['content']); 
?>

  <!--div class="slider" style='right:-20px'>
  <div class="arrow"><a href="#"><img src="<?php echo $base_url."/".$theme_path; ?>/images/slider-arrow.png" /></a></div>
  <div class="left">
  <div><img src="<?php echo $base_url."/".$theme_path; ?>/images/banner-slider-img.png" /></div>
  <p>Covidien Stories: <span>"Why my disability 
is no barrier to my...</span></p>
</div>
  </div-->
    <!--div class="slider" style='right:-20px'>
  <div class="arrow"><a href="#"><img src="<?php echo $base_url."/".$theme_path; ?>/images/slider-arrow.png" /></a></div>
  <div class="left">
  <div><img src="<?php echo $base_url."/".$theme_path; ?>/images/slider-img2.png" /></div>
  <p>Covidien Stories: <span>"Why my disability 
is no barrier to my...</span></p>
</div>
  </div-->

	 <!--div class="location" style="background-image:url('<?php echo $base_url."/".$theme_path; ?>/images/careers-location-bg.png'); padding:10px;">
  <h2>Locations</h2>
  <p>A truly global company</p>
    <div class="btn"><a href="#" style="width:210px">Latin America</a></div>
    <div class="btn"><a href="#" style="width:210px">Europe | Middle East Africa</a></div>
    <div class="btn"><a href="#" style="width:210px">Asia Pacific</a></div>
    <div class="btn"><a href="#" style="width:210px">USA</a></div>
	<div class="btn"><a href="#" style="width:210px">Canada</a></div>
 </div-->
 </div>
<?php } ?>  
  <div class="clr"></div>
 </div>
  
   
 <?php } }?>

<div id="footer">
     <div class="footerNav">
	 <?php if ($page['footer_links']): ?>        
          <?php print render($page['footer_links']); ?>      
     <?php endif; ?>
	<div class="clr"></div>     
     </div>
     <div class="socail-share">     
     <?php if ($page['social_share']): ?>        
          <?php print render($page['social_share']); ?>      
     <?php endif; ?>
     </div>
  <div class="clr"></div>     
	 <?php if ($page['copyright']): ?>        
          <?php print render($page['copyright']); ?>      
     <?php endif; ?>	
     <div class="clr"></div>
</div>
</div>         
          