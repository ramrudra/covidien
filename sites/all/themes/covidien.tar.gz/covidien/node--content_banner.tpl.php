<div class="banner"><img style="margin-bottom:-3px;" src="<?php echo "/sites/default/files/".$node->field_banner['und'][0]['filename'];?>" alt="" />
  </div>
